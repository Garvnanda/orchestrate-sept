import base64
import json
import os

import openai
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()


class ExtractionError(Exception):
    pass


USAGE_LOG_PATH = os.path.join(os.path.dirname(__file__), "evaluation", "usage_log.json")
_usage = None


def _ensure_usage_loaded():
    global _usage
    if _usage is None:
        if os.path.exists(USAGE_LOG_PATH):
            with open(USAGE_LOG_PATH, "r", encoding="utf-8") as f:
                _usage = json.load(f)
        else:
            _usage = {}


def _record_usage(provider, model, response):
    usage = getattr(response, "usage", None)
    if usage is None:
        return
    _ensure_usage_loaded()
    key = f"{provider}:{model}"
    stats = _usage.setdefault(key, {"provider": provider, "model": model, "calls": 0, "prompt_tokens": 0, "completion_tokens": 0})
    stats["calls"] += 1
    stats["prompt_tokens"] += getattr(usage, "prompt_tokens", 0) or 0
    stats["completion_tokens"] += getattr(usage, "completion_tokens", 0) or 0
    save_usage()


def _record_failure(provider, model, error):
    _ensure_usage_loaded()
    key = f"{provider}:{model}"
    stats = _usage.setdefault(key, {"provider": provider, "model": model, "calls": 0, "prompt_tokens": 0, "completion_tokens": 0})
    stats["failed_attempts"] = stats.get("failed_attempts", 0) + 1
    reason = f"http_{getattr(error, 'status_code', None)}" if getattr(error, "status_code", None) else type(error).__name__
    stats.setdefault("failure_reasons", {})
    stats["failure_reasons"][reason] = stats["failure_reasons"].get(reason, 0) + 1
    save_usage()


def get_usage():
    _ensure_usage_loaded()
    return _usage


def save_usage():
    os.makedirs(os.path.dirname(USAGE_LOG_PATH), exist_ok=True)
    with open(USAGE_LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(_usage, f, indent=2)

BASE_URL = os.environ.get("AGENTROUTER_BASE_URL", "https://agentrouter.org/v1")
USER_AGENT = os.environ.get("AGENTROUTER_USER_AGENT")

MODELS = {
    "extractor": "deepseek-v4-flash",
}

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
OPENROUTER_MODEL = "nvidia/nemotron-3-super-120b-a12b:free"
# Second read for messages AgentRouter blocks: different model families than the first reader, tried in
# order (free-tier models get rate-limited upstream; google/gemma-4-*:free returned 429 when tested).
OPENROUTER_SECOND_MODELS = ("nex-agi/nex-n2.5-pro:free", "dots-studio/dots-3-note-preview:free")

_client = None
_openrouter_client = None


def get_client():
    global _client
    if _client is None:
        default_headers = {"User-Agent": USER_AGENT} if USER_AGENT else None
        _client = OpenAI(
            base_url=BASE_URL,
            api_key=os.environ["AGENTROUTER_API_KEY"],
            default_headers=default_headers,
        )
    return _client


def get_openrouter_client():
    global _openrouter_client
    if _openrouter_client is None:
        _openrouter_client = OpenAI(base_url=OPENROUTER_BASE_URL, api_key=os.environ["OPENROUTER_API_KEY"])
    return _openrouter_client


def _image_data_url(image_path):
    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return f"data:image/png;base64,{b64}"


def _chat_json(client, model, system_prompt, text_prompt, image_path=None, max_retries=1, provider="agentrouter"):
    if image_path:
        user_content = [
            {"type": "text", "text": text_prompt},
            {"type": "image_url", "image_url": {"url": _image_data_url(image_path)}},
        ]
    else:
        user_content = text_prompt

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]
    last_error = None
    for _ in range(max_retries + 1):
        try:
            response = client.chat.completions.create(
                model=model, messages=messages, response_format={"type": "json_object"}, temperature=0,
            )
        except openai.APIError as e:
            last_error = e
            _record_failure(provider, model, e)
            status = getattr(e, "status_code", None)
            if status is not None and status < 500 and status != 429:
                break  # deterministic rejection (e.g. content-blocked) — retrying the same request wastes a call
            continue
        _record_usage(provider, model, response)
        if not response.choices or response.choices[0].message.content is None:
            last_error = f"empty response (finish_reason={getattr(response.choices[0], 'finish_reason', None) if response.choices else 'no choices'})"
            continue
        text = response.choices[0].message.content
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            last_error = e
    raise ExtractionError(f"{model} call failed after {max_retries + 1} attempts: {last_error}")


def call_json(role, system_prompt, text_prompt, image_path=None, max_retries=1):
    return _chat_json(get_client(), MODELS[role], system_prompt, text_prompt, image_path, max_retries, provider="agentrouter")


def call_json_openrouter(system_prompt, text_prompt, image_path=None, max_retries=1, model=OPENROUTER_MODEL):
    return _chat_json(
        get_openrouter_client(), model, system_prompt, text_prompt, image_path, max_retries,
        provider="openrouter",
    )


def _self_check():
    result = call_json(
        "extractor",
        "Reply with strict JSON only.",
        'Reply with exactly this JSON object: {"ok": true}',
    )
    assert result == {"ok": True}, result
    print("OK: AgentRouter connectivity + JSON mode working via deepseek-v4-flash")


if __name__ == "__main__":
    _self_check()
